#!/bin/bash

[[ -e $(which curl) ]] && grep -q "1.1.1.1" /etc/resolv.conf || { 
    echo "nameserver 1.1.1.1" | cat - /etc/resolv.conf >> /etc/resolv.conf.tmp && mv /etc/resolv.conf.tmp /etc/resolv.conf
}


    # Konfigurasi URL izin
    PERMISSION_URL="https://permision.rerechanstore.eu.org/izin.txt"
    LOCAL_IP=$(curl -s ifconfig.me) # Mendapatkan IP lokal

    # Fungsi menghitung sisa waktu
    calculate_remaining_days() {
        local today=$(date +%s)
        local expired_date=$(date -d "$1" +%s 2>/dev/null)
        if [ $? -ne 0 ]; then
            echo "Tanggal kadaluwarsa tidak valid."
            exit 1
        fi
        echo $(( (expired_date - today) / 86400 ))
    }

    # Unduh izin dan validasi
    clear
    PERMISSION_DATA=$(curl -s "$PERMISSION_URL" || { echo "Gagal mengunduh izin."; exit 1; })

    # Mencocokkan data berdasarkan IP lokal
    MATCH=$(echo "$PERMISSION_DATA" | grep "###" | grep "$LOCAL_IP")
    if [ -z "$MATCH" ]; then
        echo "Your IP doesn’t have on database"
        exit 1
    fi

    # Ekstraksi data dari baris yang cocok
    USERNAME=$(echo "$MATCH" | awk '{print $2}')
    PERMISSION_IP=$(echo "$MATCH" | awk '{print $3}')
    EXPIRED_DATE=$(echo "$MATCH" | awk '{print $4}')

    # Validasi masa aktif
    REMAINING_DAYS=$(calculate_remaining_days "$EXPIRED_DATE")
    if [ "$REMAINING_DAYS" -lt 0 ]; then
        echo "Izin telah kadaluwarsa."
        exit 1
    fi

    # Output informasi izin
    output() {
        echo "Username: $USERNAME"
        echo "IPv4: $PERMISSION_IP"
        echo "Expired: $EXPIRED_DATE ( $REMAINING_DAYS Days )"
    }

    output

# Detail Hosting
hosting="https://scvps.rerechanstore.eu.org"
clear

# Menginstall Core
xver=$(curl -sS https://raw.githubusercontent.com/DindaPutriFN/sslh/main/version.conf)
bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install -u www-data --version $xver
rm -fr /etc/systemd/system/xray.service
rm -fr /etc/systemd/system/xray.service.d
rm -fr /etc/systemd/system/xray@.service
rm -fr /etc/systemd/system/xray@.service.d
cat> /etc/systemd/system/xray@.service << MLBB
[Unit]
Description=Xray Service
Documentation=https://github.com/xtls
After=network.target nss-lookup.target

[Service]
User=www-data
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ExecStart=/usr/local/bin/xray run -config /etc/xray/json/%i.json
Restart=on-failure
RestartPreventExitStatus=23
LimitNPROC=10000
LimitNOFILE=1000000

[Install]
WantedBy=multi-user.target
MLBB
systemctl daemon-reload
clear

# Mengcopy Json
mkdir -p /etc/xray/json
cd /etc/xray/json
wget --no-check-certificate ${hosting}/json/ws.json >> /dev/null 2>&1
wget --no-check-certificate ${hosting}/json/upgrade.json >> /dev/null 2>&1
wget --no-check-certificate ${hosting}/json/split.json >> /dev/null 2>&1
wget --no-check-certificate ${hosting}/json/grpc.json >> /dev/null 2>&1

# Mengubah Permision Json
chmod +x ws.json
chmod +x upgrade.json
chmod +x split.json
chmod +x grpc.json

# Membuat File Log
mkdir -p /var/log/xray
cd /var/log/xray
touch /var/log/xray/ws.log
touch /var/log/xray/split.log
touch /var/log/xray/upgrade.log
touch /var/log/xray/grpc.log
touch /etc/xray/.quota.logs

# Mengubah Permision Log File
chmod +x ws.log
chmod +x split.log
chmod +x upgrade.log
chmod +x grpc.log
chmod +x /etc/xray/.quota.logs

# Membuat Service Limit Quota
cat> /etc/systemd/system/quota-ws.service << END
[Unit]
Description=Xray Quota Management Service By FN Project
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/quota-ws
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
END

cat> /etc/systemd/system/quota-split.service << END
[Unit]
Description=Xray Quota Management Service By FN Project
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/quota-split
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
END

cat> /etc/systemd/system/quota-http.service << END
[Unit]
Description=Xray Quota Management Service By FN Project
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/quota-http
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
END

cat> /etc/systemd/system/quota-grpc.service << END
[Unit]
Description=Xray Quota Management Service By FN Project
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/quota-grpc
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
END

# Menyalakan Service
systemctl daemon-reload
systemctl enable xray@ws
systemctl enable quota-ws
systemctl enable xray@upgrade
systemctl enable quota-http
systemctl enable xray@split
systemctl enable quota-split
systemctl enable xray@grpc
systemctl enable quota-grpc

# Melakukan Start Service
systemctl start xray@ws
systemctl start quota-ws
systemctl start xray@upgrade
systemctl start quota-http
systemctl start xray@split
systemctl start quota-split
systemctl start xray@grpc
systemctl start quota-grpc

cd

# Menghapus file tidak penting
rm -f /root/xray.sh
