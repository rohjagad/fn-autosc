#!/bin/bash

[[ -e $(which curl) ]] && grep -q "1.1.1.1" /etc/resolv.conf || { 
    echo "nameserver 1.1.1.1" | cat - /etc/resolv.conf >> /etc/resolv.conf.tmp && mv /etc/resolv.conf.tmp /etc/resolv.conf
}

    # Konfigurasi URL izin
    PERMISSION_URL="https://permision.rerechanstore.eu.org/izin.txt"
    LOCAL_IP=$(curl -s ifconfig.me) # Mendapatkan IP lokal

    # Fungsi menghitung sisa waktu
    calculate_remaining_days() {
        local today=$(date +%s)
        local expired_date=$(date -d "$1" +%s 2>/dev/null)
        if [ $? -ne 0 ]; then
            echo "Tanggal kadaluwarsa tidak valid."
            exit 1
        fi
        echo $(( (expired_date - today) / 86400 ))
    }

    # Unduh izin dan validasi
    clear
    PERMISSION_DATA=$(curl -s "$PERMISSION_URL" || { echo "Gagal mengunduh izin."; exit 1; })

    # Mencocokkan data berdasarkan IP lokal
    MATCH=$(echo "$PERMISSION_DATA" | grep "###" | grep "$LOCAL_IP")
    if [ -z "$MATCH" ]; then
        echo "Your IP doesn’t have on database"
        exit 1
    fi

    # Ekstraksi data dari baris yang cocok
    USERNAME=$(echo "$MATCH" | awk '{print $2}')
    PERMISSION_IP=$(echo "$MATCH" | awk '{print $3}')
    EXPIRED_DATE=$(echo "$MATCH" | awk '{print $4}')

    # Validasi masa aktif
    REMAINING_DAYS=$(calculate_remaining_days "$EXPIRED_DATE")
    if [ "$REMAINING_DAYS" -lt 0 ]; then
        echo "Izin telah kadaluwarsa."
        exit 1
    fi

    # Output informasi izin
    output() {
        echo "Username: $USERNAME"
        echo "IPv4: $PERMISSION_IP"
        echo "Expired: $EXPIRED_DATE ( $REMAINING_DAYS Days )"
    }

    output
clear
clear

restore() {
# Detail Informasi
ip6=$(curl -sS ipv4.icanhazip.com)
ip4=$(curl -sS ipv6.icanhazip.com)
ip="$ip4 / $ip6"
date=$(date)
domain=$(cat /etc/xray/domain)
clear
read -rp "Input Link Database: " url

cd /root
wget -O backup.zip "$url"
unzip backup.zip
rm -f backup.zip
sleep 1
echo "Tengah Melakukan Backup Data"
cd /root/backup
cp passwd /etc/
cp group /etc/
cp shadow /etc/
cp gshadow /etc/
cp crontab /etc/
cp -r xray /etc/
cp -r funny /etc/
cp -r create /var/log/

systemctl daemon-reload
systemctl restart ssh
systemctl restart xray@ws
systemctl restart xray@grpc
systemctl restart xray@split
systemctl restart xray@upgrade
systemctl restart nginx
systemctl restart cron
clear

#echo "Telah Berjaya Melakukan Backup"
  echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "SUCCESSFULL RESTORE YOUR VPS"
    echo -e "Please Save The Following Data"
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "Your VPS IP : $ip"
    echo -e "DOMAIN      : $domain"
    echo -e "DATE        : $date"
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
}

restf() {
# Detail Informasi
ip6=$(curl -sS ipv4.icanhazip.com)
ip4=$(curl -sS ipv6.icanhazip.com)
ip="$ip4 / $ip6"
date=$(date)
domain=$(cat /etc/xray/domain)
clear
cd /root
mv /root/*.zip /root/backup.zip
file="backup.zip"
if [ -f "$file" ]; then
echo "$file ditemukan, melanjutkan proses..."
sleep 2
clear
unzip backup.zip
rm -f backup.zip
sleep 1
echo "Tengah Melakukan Backup Data"
cd /root/backup
cp passwd /etc/
cp group /etc/
cp shadow /etc/
cp gshadow /etc/
cp crontab /etc/
cp -r xray /etc/
cp -r funny /etc/
cp -r create /var/log/

systemctl daemon-reload
systemctl restart ssh
systemctl restart xray@ws
systemctl restart xray@grpc
systemctl restart xray@split
systemctl restart xray@upgrade
systemctl restart nginx
systemctl restart cron
clear

#echo "Telah Berjaya Melakukan Backup"
  echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "SUCCESSFULL RESTORE YOUR VPS"
    echo -e "Please Save The Following Data"
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "Your VPS IP : $ip"
    echo -e "DOMAIN      : $domain"
    echo -e "DATE        : $date"
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
else
    echo "Error: File $file Not Found"
fi
}

bmenu() {
clear
echo -e "
============================
<= Backup Database Server =>
============================

1. Backup Database 1
2. Backup Database 2
3. Restore Database Via Link
3. Restore Database Via File
============================
   Press CTRL + C TO EXIT
============================"
read -p "Input Option: " opa
case $opa in
1) clear ; backup ;;
2) clear ; backup-gd ;;
3) clear ; restore ;;
4) clear ; restf ;;
*) clear ; bmenu ;;
esac
}

bmenu
